package com.kiranacademy.onlineexam3;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController 
{
	@Autowired
	SessionFactory factory;
	
	@RequestMapping("showlogin")
	public String showlogin()
	{
		return "login";
	}

	@RequestMapping("showregister")
	public String showregister()
	{
		return "register";
	}
	
	@RequestMapping("validate")
	public ModelAndView validate(String username,String password)
	{
		System.out.println("username from browser " + username);
		System.out.println("password from browser " + password);
		
		ModelAndView modelAndView=new ModelAndView();
		
		//username=jbk
		//password=java
		
		Session session=factory.openSession();
		
		Users users=session.load(Users.class,username);
		
		System.out.println(users.getUsername() + " " + users.getPassword());
		
		// users==> [username=jbk password=jbk] Users class object
		
		if(username.equals(users.getUsername()) && password.equals(users.getPassword()))
		{
			modelAndView.setViewName("welcome");
			modelAndView.addObject("message","welcome " + username);
		}
		
		else
		{
			modelAndView.setViewName("login");
			modelAndView.addObject("message","invalid credentials");
		}
		
		return modelAndView;
		
	}
}
